Witaj Maksu!

Ten folder zawiera gotową do działania symulację na systemie Windows (przez WSL2 / Ubuntu).

--- JAK ZAINSTALOWAĆ (Tylko raz!) ---
1. Skopiuj ten cały folder "WSL2_Symulacja" do środka swojego WSL2 (np. na `/home/TWOJ_USER/WSL2_Symulacja`).
   Najlepiej wejdź do folderu w Terminalu Ubuntu i odpal:
   `chmod +x install_wsl2.sh run_wsl2.sh`
   
2. Uruchom skrypt instalacyjny:
   `./install_wsl2.sh`

Skrypt automatycznie pobierze Geant4, skompiluje go z obsługą graficzną, zbuduje naszą aplikację, i zainstaluje wszystko do Pythona (będzie to u Ciebie pod Windowsem działać Out Of The Box - nowoczesne WSL2 obsługuje otwieranie okienek Qt automatycznie).
Kompilacja Geant4 może chwilę potrwać (ok. 15-30 min), więc warto zrobić sobie przerwę.

--- JAK URUCHAMIAĆ ---
Kiedy instalacja się skończy, wystarczy, że wejdziesz w ten folder w terminalu WSL2 (Ubuntu) i wpiszesz:
`./run_wsl2.sh`

(Aplikacja Geant4 i GUI Same się załadują i otworzą normalnie okienko na Windowsie!)
